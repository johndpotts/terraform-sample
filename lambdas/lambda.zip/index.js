exports.handler = async(event, context)=>{
    return 'hello, world from terraform!';
}